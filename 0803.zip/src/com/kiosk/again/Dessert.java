package com.kiosk.again;

public class Dessert extends Food{

}
