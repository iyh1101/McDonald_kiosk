package com.kiosk.again;

public class Mcdonald {
	public static void main(String[] args) {
		KioskAgain ka = new KioskAgain();
		ka.kiosk(null);
	}
}
