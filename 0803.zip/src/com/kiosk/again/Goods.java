package com.kiosk.again;

public class Goods {
	public int price;
	public String name;
	
	public Goods() {
		this.price = price;
		this.name = name;
	}
}
