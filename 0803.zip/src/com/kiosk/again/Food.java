package com.kiosk.again;

public class Food extends Goods{
	public String extraDate;
	
}
