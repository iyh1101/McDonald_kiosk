package com.kiosk.again;

public class Burger extends Food{

}
