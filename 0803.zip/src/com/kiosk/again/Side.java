package com.kiosk.again;

public class Side extends Food{

}
